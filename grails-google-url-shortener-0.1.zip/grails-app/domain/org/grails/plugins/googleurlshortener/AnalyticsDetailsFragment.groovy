package org.grails.plugins.googleurlshortener


class AnalyticsDetailsFragment {
	int labelCount
	String label
    static constraints = {
    }
}
