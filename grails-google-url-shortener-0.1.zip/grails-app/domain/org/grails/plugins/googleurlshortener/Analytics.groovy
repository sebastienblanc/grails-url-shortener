package org.grails.plugins.googleurlshortener


class Analytics {
	AnalyticsDetails allTime
	AnalyticsDetails month
	AnalyticsDetails week
	AnalyticsDetails day
	AnalyticsDetails twoHours
    static constraints = {
    }
}
